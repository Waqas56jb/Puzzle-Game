#!/bin/bash

read -p "Enter the board size (e.g., 3 for a 3x3 board): " boardSize
declare -A board
declare -A goalstate
zeroRow=0
zeroCol=0
moves=()
########################################## GOAL FUNCTION ###########################################
goal() {
     echo "%%%%%% (ENTER GOAL STATE RENDOMLY) %%%%%%%"
    for ((i = 0; i < boardSize; i++)); do
        for ((j = 0; j < boardSize; j++)); do
            read -p "Enter value for cell $i,$j: " value
            goalstate["$i,$j"]=$value
        done
    done

    echo -e "\nGoal State is:\n"
    for ((i = 0; i < boardSize; i++)); do
        for ((j = 0; j < boardSize; j++)); do
            printf "%4s" "${goalstate["$i,$j"]}"
        done
        echo
    done
}
########################################## IS_GOAL FUNCTION ###########################################
is_goal() {
    local isGoal=true

    for ((i = 0; i < boardSize; i++)); do
        for ((j = 0; j < boardSize; j++)); do
            local currentState="${board["$i,$j"]}"
            local goalValue="${goalstate["$i,$j"]}"
            if [ "$currentState" -ne "$goalValue" ]; then
                isGoal=false
                break
            fi
        done
        if [ "$isGoal" = false ]; then
            break
        fi
    done

    echo "$isGoal"
}
########################################## LEGAL_MOVE FUNCTION ###########################################
legal_moves() {
    local state=("$@")
    local legalMoves=()

    if ((zeroRow > 0)); then
        legalMoves+=("U")
    fi
    if ((zeroRow < boardSize - 1)); then
        legalMoves+=("D")
    fi
    if ((zeroCol > 0)); then
        legalMoves+=("L")
    fi
    if ((zeroCol < boardSize - 1)); then
        legalMoves+=("R")
    fi

    echo "${legalMoves[@]}"
}
########################################## IS_SOLVEABLE  FUNCTION ###########################################
Is_Solveable() {
    local goalState=("$@")
    local inversions=0

    # Flatten the goal state
    local flatGoal=()
    for ((i = 0; i < boardSize; i++)); do
        for ((j = 0; j < boardSize; j++)); do
            flatGoal+=(${goalState["$i,$j"]})
        done
    done

    # Calculate the number of inversions
    for ((i = 0; i < ${#flatGoal[@]}; i++)); do
        for ((j = i + 1; j < ${#flatGoal[@]}; j++)); do
            if [[ ${flatGoal[i]} -ne 0 && ${flatGoal[j]} -ne 0 && ${flatGoal[i]} > ${flatGoal[j]} ]]; then
                inversions=$((inversions + 1))
            fi
        done
    done

    # Check if the board size is even
    if ((boardSize % 2 == 0)); then
        # Even-sized board
        # An even number of inversions is solvable
        if ((inversions % 2 == 0)); then
            echo "The puzzle is solvable."
        else
            echo "The puzzle is not solvable."
        fi
    else
        # Odd-sized board
        # Inversions plus the row of the blank square is even, the puzzle is solvable
        local zeroRow=$((boardSize - zeroRow))
        local totalInversions=$((inversions + zeroRow))
        if ((totalInversions % 2 == 0)); then
            echo "The puzzle is solvable."
        else
            echo "The puzzle is not solvable."
        fi
    fi
}

moveRight() {
    if ((zeroCol < boardSize - 1)); then
        local newRow=$zeroRow
        local newCol=$((zeroCol + 1))
        board["$zeroRow,$zeroCol"]=${board["$newRow,$newCol"]}
        board["$newRow,$newCol"]=0
        zeroRow=$newRow
        zeroCol=$newCol
        moves+=("R")
    fi
}

moveLeft() {
    if ((zeroCol > 0)); then
        local newRow=$zeroRow
        local newCol=$((zeroCol - 1))
        board["$zeroRow,$zeroCol"]=${board["$newRow,$newCol"]}
        board["$newRow,$newCol"]=0
        zeroRow=$newRow
        zeroCol=$newCol
        moves+=("L")
    fi
}

moveUp() {
    if ((zeroRow > 0)); then
        local newRow=$((zeroRow - 1))
        local newCol=$zeroCol
        board["$zeroRow,$zeroCol"]=${board["$newRow,$newCol"]}
        board["$newRow,$newCol"]=0
        zeroRow=$newRow
        zeroCol=$newCol
        moves+=("U")
    fi
}

moveDown() {
    if ((zeroRow < boardSize - 1)); then
        local newRow=$((zeroRow + 1))
        local newCol=$zeroCol
        board["$zeroRow,$zeroCol"]=${board["$newRow,$newCol"]}
        board["$newRow,$newCol"]=0
        zeroRow=$newRow
        zeroCol=$newCol
        moves+=("D")
    fi
}

displayBoard() {
    echo "************* (Board Display) ****************"
    for ((i = 0; i < boardSize; i++)); do
        for ((j = 0; j < boardSize; j++)); do
            printf "%4s" "${board["$i,$j"]}"
        done
        echo
    done
}
########################################## MAKE MOVE FUNCTION ###########################################
makeMove() {
 
    while true; do
        local availableMoves=($(legal_moves "${board[@]}"))
        read -n1 -p "Enter R/L/U/D to move (Q to quit): " direction
        if [[ " ${availableMoves[*]} " == *" $direction "* ]]; then
            echo
            case "$direction" in
                [Rr]) moveRight ;;
                [Ll]) moveLeft ;;
                [Uu]) moveUp ;;
                [Dd]) moveDown ;;
                [Qq]) echo "You quit the game."; break ;;
            esac
        else
            echo -e "\nInvalid move. Please enter a valid move.\n"
        fi
        displayBoard

        # Check if the puzzle is solved
        if $(is_goal "${!board[@]}"); then
            echo "Congratulations! You solved the puzzle."
            
 
            print_path
            break  # Exit the loop when the puzzle is solved
        fi
    done
}
########################################## INIT() FUNCTION ###########################################
init() {
 echo "%%%%%% (INITILIZAED INITIAL STATE ) %%%%%%%"
    echo "Initializing the ${boardSize}x${boardSize} board:"
    for ((i = 0; i < boardSize; i++)); do
        for ((j = 0; j < boardSize; j++)); do
            read -p "Enter value for cell $i,$j: " value
            board["$i,$j"]=$value
            if [[ "$value" -eq 0 ]]; then
                zeroRow=$i
                zeroCol=$j
            fi
        done
    done

    echo -e "\nZero is present at ($zeroRow, $zeroCol)"
    displayBoard
}
########################################## PRINT PATH FUNCTION ###########################################
print_path() {
    echo "%%%%%% (PATH FOLLOWED ) %%%%%%%"
    echo "Sequence of moves taken:"
    for move in "${moves[@]}"; do
        case "$move" in
            R) echo "Right" ;;
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																	            L) echo "Left" ;;
            U) echo "Up" ;;
            D) echo "Down" ;;
        esac
    done
    echo "Total Moves: ${#moves[@]}"
}

init
goal
Is_Solveable goalstate

if $(is_goal "${!board[@]}"); then
    echo "The initial board matches the goal state."
else
    makeMove
fi

